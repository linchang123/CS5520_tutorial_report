//
//  View.swift
//  charts_demo
//
//  Created by Chang Lin on 12/5/24.
//
import Charts
import UIKit

class View: UIView {

     var contentWrapper: UIScrollView!
     var barChart: BarChartView!
     var lineChart: LineChartView!
     var pieChart: PieChartView!
     
     override init(frame: CGRect) {
         super.init(frame: frame)
         self.backgroundColor = .white
         
         setupContentWrapper()
         setupBarChart()
         setupLineChart()
         setupPieChart()
         initConstraints()
     }
     
     func setupContentWrapper() {
         contentWrapper = UIScrollView()
         contentWrapper.isScrollEnabled = true
         contentWrapper.showsVerticalScrollIndicator = true
         contentWrapper.translatesAutoresizingMaskIntoConstraints = false
         self.addSubview(contentWrapper)
     }
     
     func setupBarChart() {
         barChart = BarChartView()
         barChart.translatesAutoresizingMaskIntoConstraints = false
         contentWrapper.addSubview(barChart)
     }
     
     func setupLineChart() {
         lineChart = LineChartView()
         lineChart.translatesAutoresizingMaskIntoConstraints = false
         contentWrapper.addSubview(lineChart)
     }
     
     func setupPieChart() {
         pieChart = PieChartView()
         pieChart.usePercentValuesEnabled = true
         pieChart.legend.enabled = true
         pieChart.translatesAutoresizingMaskIntoConstraints = false
         contentWrapper.addSubview(pieChart)
     }
     
     func initConstraints() {
         NSLayoutConstraint.activate([
             contentWrapper.topAnchor.constraint(equalTo: self.safeAreaLayoutGuide.topAnchor),
             contentWrapper.leadingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.leadingAnchor),
             contentWrapper.widthAnchor.constraint(equalTo: self.safeAreaLayoutGuide.widthAnchor),
             contentWrapper.heightAnchor.constraint(equalTo: self.safeAreaLayoutGuide.heightAnchor),
              contentWrapper.trailingAnchor.constraint(equalTo: self.safeAreaLayoutGuide.trailingAnchor),
             contentWrapper.bottomAnchor.constraint(equalTo: self.safeAreaLayoutGuide.bottomAnchor),
             
             barChart.topAnchor.constraint(equalTo: contentWrapper.topAnchor, constant: 32),
             barChart.centerXAnchor.constraint(equalTo: contentWrapper.centerXAnchor),
             barChart.widthAnchor.constraint(equalTo: contentWrapper.widthAnchor),
             barChart.heightAnchor.constraint(equalToConstant: 300),
             
             lineChart.topAnchor.constraint(equalTo: barChart.bottomAnchor, constant: 30),
             lineChart.centerXAnchor.constraint(equalTo: contentWrapper.centerXAnchor),
             lineChart.widthAnchor.constraint(equalTo: contentWrapper.widthAnchor),
             lineChart.heightAnchor.constraint(equalToConstant: 300),
             
             pieChart.topAnchor.constraint(equalTo: lineChart.bottomAnchor, constant: 30),
             pieChart.centerXAnchor.constraint(equalTo: contentWrapper.centerXAnchor),
             pieChart.widthAnchor.constraint(equalTo: contentWrapper.widthAnchor),
             pieChart.heightAnchor.constraint(equalToConstant: 300),
             pieChart.bottomAnchor.constraint(equalTo: contentWrapper.bottomAnchor)
         ])
     }
     
     required init?(coder: NSCoder) {
         fatalError("init(coder:) has not been implemented")
     }

}
