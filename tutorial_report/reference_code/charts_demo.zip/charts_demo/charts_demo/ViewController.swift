//
//  ViewController.swift
//  charts_demo
//
//  Created by Chang Lin on 12/5/24.
//

import UIKit
import Charts

class ViewController: UIViewController {

    let mainScreen = View()
     //MARK: adding example data
     let months: [String] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
     let monthlyData: [Double] = [1200, 1500, 2000, 1745, 1487, 1865, 2100, 1000, 1762, 2258, 2197, 2074]
     
    override func loadView() {
        view = mainScreen
    }
     
     override func viewDidLoad() {
         super.viewDidLoad()
         
         mainScreen.barChart.delegate = self
         mainScreen.lineChart.delegate = self
         mainScreen.pieChart.delegate = self
         
         setupBarChart()
         setupLineChart()
         setupPieChart()
     }

     func setupBarChart() {
         // MARK: set up data for bar chart
         var barChartDataEntries: [BarChartDataEntry] = []
         for num in 0...months.count - 1 {
             barChartDataEntries.append(BarChartDataEntry(x: Double(num), y: monthlyData[num]))
         }
         let barChartDataSet = BarChartDataSet(entries: barChartDataEntries)
         barChartDataSet.colors = ChartColorTemplates.colorful()
         let barChartData = BarChartData(dataSet: barChartDataSet)
         mainScreen.barChart.data = barChartData
         
         // MARK: additional chart customizations
         mainScreen.barChart.rightAxis.enabled = false
         mainScreen.barChart.leftAxis.axisMinimum = 0
         mainScreen.barChart.animate(yAxisDuration: 2.5)
         
         //MARK: set up x labels for bar chart
         mainScreen.barChart.xAxis.valueFormatter = IndexAxisValueFormatter(values: months)
         mainScreen.barChart.xAxis.granularity = 1
         mainScreen.barChart.xAxis.labelPosition = .bottom
     }
    
    func setupLineChart() {
        // MARK: set up data for line chart
        var lineChartDataEntries: [ChartDataEntry] = []
        for num in 0...months.count - 1 {
            lineChartDataEntries.append(ChartDataEntry(x: Double(num), y: monthlyData[num]))
        }
        let lineChartDataSet = LineChartDataSet(entries: lineChartDataEntries)
        lineChartDataSet.colors = ChartColorTemplates.colorful()
        let lineChartData = LineChartData(dataSet: lineChartDataSet)
        mainScreen.lineChart.data = lineChartData
            
        //MARK: set up x labels for line chart
        mainScreen.lineChart.xAxis.valueFormatter = IndexAxisValueFormatter(values: months)
        mainScreen.lineChart.xAxis.granularity = 1
        mainScreen.lineChart.xAxis.labelPosition = .bottom
            
        // MARK: Additional Chart Customizations
        mainScreen.lineChart.rightAxis.enabled = false
        mainScreen.lineChart.leftAxis.axisMinimum = 0
        mainScreen.lineChart.legend.enabled = true
        mainScreen.lineChart.animate(yAxisDuration: 3.0)
        
    }
    
    func setupPieChart() {
        // MARK: set up data for pie chart
        var pieChartDataEntries: [ChartDataEntry] = []
        for num in 0...months.count - 1 {
            pieChartDataEntries.append(ChartDataEntry(x: Double(num), y: monthlyData[num]))
        }
        let pieChartDataSet = PieChartDataSet(entries: pieChartDataEntries)
        pieChartDataSet.colors = ChartColorTemplates.colorful()
        pieChartDataSet.drawValuesEnabled = false
        let pieChartData = PieChartData(dataSet: pieChartDataSet)
        mainScreen.pieChart.data = pieChartData
        mainScreen.pieChart.animate(yAxisDuration: 2.5)
    }
    
}

extension ViewController: ChartViewDelegate {
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
//        NSLog("chartValueSelected");
        print()
        if chartView is BarChartView {
            print("user taps a value in the bar chart")
        } else if chartView is LineChartView {
            print("user taps a value in the line chart")
        } else {
            // MARK: the selected data must be from the pie chart
            print("user taps a value in the pie chart")
        }
        print("the data point is \(entry)")
    }
    
    func chartValueNothingSelected(_ chartView: ChartViewBase) {
        NSLog("chartValueNothingSelected");
        
    }
    
    func chartScaled(_ chartView: ChartViewBase, scaleX: CGFloat, scaleY: CGFloat) {
        
    }
    
    func chartTranslated(_ chartView: ChartViewBase, dX: CGFloat, dY: CGFloat) {
        
    }
}

